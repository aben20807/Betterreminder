<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CmdProcess</name>
    <message>
        <location filename="../../cmdprocess.cpp" line="47"/>
        <location filename="../../cmdprocess.cpp" line="50"/>
        <source>Remind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../cmdprocess.cpp" line="47"/>
        <source>Battery level is more than </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../cmdprocess.cpp" line="50"/>
        <source>Battery level is less than </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Log</name>
    <message>
        <location filename="../../log.ui" line="14"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../mainwindow.ui" line="14"/>
        <source>Betterreminder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="40"/>
        <location filename="../../mainwindow.ui" line="412"/>
        <source>Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="77"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="105"/>
        <source>[+]batteryStatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="136"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="164"/>
        <source>Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="192"/>
        <source>[+]batteryLevel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="219"/>
        <source>Battery level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="294"/>
        <source>The connection status to database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="303"/>
        <source>[+]connectStatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="348"/>
        <source>Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="360"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="370"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="380"/>
        <source>Minimize To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="396"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="419"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="431"/>
        <source>Minimize To System Tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="445"/>
        <source>English_US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="459"/>
        <source>繁體中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="473"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="482"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="487"/>
        <source>Check Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="496"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="501"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="506"/>
        <source>System tray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="511"/>
        <source>Taskbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="516"/>
        <location filename="../../mainwindow.cpp" line="520"/>
        <source>Error Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="521"/>
        <location filename="../../mainwindow.cpp" line="534"/>
        <source>About Betterreminder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="526"/>
        <source>Action Explanation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="531"/>
        <location filename="../../mainwindow.cpp" line="565"/>
        <source>About Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="536"/>
        <location filename="../../mainwindow.cpp" line="581"/>
        <source>Reference or Resource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="21"/>
        <source>Failed to connect db!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="42"/>
        <location filename="../../mainwindow.cpp" line="462"/>
        <location filename="../../mainwindow.cpp" line="478"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="42"/>
        <source>Failed to create log file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="342"/>
        <source>Error a::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="462"/>
        <source>Failed to open log to write!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="478"/>
        <source>Failed to open log to read!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="521"/>
        <source>Let me know by following method
GitHub : https://github.com/aben20807</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="536"/>
        <source>aben20807&apos;s Program

Betterreminder is for Better Battery Reminder
LICENSE : GPLv3
I wrote this program for practicing. OuO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="551"/>
        <source>Action Explaintion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="566"/>
        <source>
I will say strongly recommend you just to use &quot;Remind&quot; action
&quot;Help -&gt; Action Explaintion&quot; are my experiences or data form website
Score : 5 -&gt; Good, 1 -&gt; Bad
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="582"/>
        <source>Action Explaintion : https://www.foolegg.com/what-are-the-differences-between-shut-down-standby-sleep-hibernate-and-hybrid-sleep/
Language Icon : https://www.iconfinder.com/iconsets/142-mini-country-flags-16x16px
Other Icon : material-design-icons-2.2.0 form https://design.google.com/icons/</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Schedule</name>
    <message>
        <location filename="../../schedule.ui" line="14"/>
        <source>Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="47"/>
        <source>Action to do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="70"/>
        <location filename="../../schedule.ui" line="303"/>
        <location filename="../../schedule.ui" line="438"/>
        <location filename="../../schedule.ui" line="573"/>
        <source>Choose one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="75"/>
        <location filename="../../schedule.ui" line="308"/>
        <location filename="../../schedule.ui" line="443"/>
        <location filename="../../schedule.ui" line="578"/>
        <source>If level &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="80"/>
        <location filename="../../schedule.ui" line="313"/>
        <location filename="../../schedule.ui" line="448"/>
        <location filename="../../schedule.ui" line="583"/>
        <source>If level &lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="100"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="122"/>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="163"/>
        <location filename="../../schedule.ui" line="280"/>
        <location filename="../../schedule.ui" line="415"/>
        <location filename="../../schedule.ui" line="550"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="186"/>
        <location filename="../../schedule.ui" line="334"/>
        <location filename="../../schedule.ui" line="469"/>
        <location filename="../../schedule.ui" line="604"/>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="191"/>
        <location filename="../../schedule.ui" line="339"/>
        <location filename="../../schedule.ui" line="474"/>
        <location filename="../../schedule.ui" line="609"/>
        <source>Remind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="196"/>
        <location filename="../../schedule.ui" line="344"/>
        <location filename="../../schedule.ui" line="479"/>
        <location filename="../../schedule.ui" line="614"/>
        <source>Shut down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="201"/>
        <location filename="../../schedule.ui" line="349"/>
        <location filename="../../schedule.ui" line="484"/>
        <location filename="../../schedule.ui" line="619"/>
        <source>Sleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="206"/>
        <location filename="../../schedule.ui" line="354"/>
        <location filename="../../schedule.ui" line="489"/>
        <location filename="../../schedule.ui" line="624"/>
        <source>Hibernate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="226"/>
        <source>1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="374"/>
        <source>2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="509"/>
        <source>3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="644"/>
        <source>4.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="672"/>
        <source>The connection status to database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.ui" line="675"/>
        <source>[+]connectStatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="97"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="97"/>
        <source>Need to input legal level!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="113"/>
        <source>Error u1::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="121"/>
        <source>Error u2::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="129"/>
        <source>Error u3::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="137"/>
        <source>Error u4::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="161"/>
        <source>Error r1::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="173"/>
        <source>Error r2::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="185"/>
        <source>Error r3::</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../schedule.cpp" line="197"/>
        <source>Error r4::</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
